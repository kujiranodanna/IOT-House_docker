#!/bin/bash
epicon -q -d 30 -D 50 -l /dev/ttyS1 
